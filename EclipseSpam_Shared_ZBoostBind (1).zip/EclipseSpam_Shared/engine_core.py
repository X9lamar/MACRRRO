"""Sticky + Combo + side/middle mouse + config-aware."""
import time
import threading
import json
import os
import sys

try:
    import keyboard
except ImportError:
    keyboard = None

try:
    import ctypes
    from ctypes import wintypes, CFUNCTYPE, POINTER, byref
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    HAVE_CTYPES = True
except Exception:
    HAVE_CTYPES = False
    user32 = None

LLKHF_INJECTED = 0x10
WH_KEYBOARD_LL, WH_MOUSE_LL = 13, 14
WM_KEYDOWN, WM_KEYUP = 0x0100, 0x0101
WM_SYSKEYDOWN, WM_SYSKEYUP = 0x0104, 0x0105
WM_XBUTTONDOWN, WM_XBUTTONUP = 0x020B, 0x020C
WM_MBUTTONDOWN, WM_MBUTTONUP = 0x0207, 0x0208
HC_ACTION = 0
MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP = 0x0002, 0x0004
VK_XBUTTON1, VK_XBUTTON2, VK_MBUTTON = 0x05, 0x06, 0x04
ULONG_PTR = ctypes.c_ulonglong if HAVE_CTYPES and ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_ulong

if HAVE_CTYPES:
    class KBDLLHOOKSTRUCT(ctypes.Structure):
        _fields_ = [("vkCode", wintypes.DWORD), ("scanCode", wintypes.DWORD),
                    ("flags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]
    class MSLLHOOKSTRUCT(ctypes.Structure):
        _fields_ = [("pt", wintypes.POINT), ("mouseData", wintypes.DWORD),
                    ("flags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]
    class MOUSEINPUT(ctypes.Structure):
        _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                    ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]
    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
                    ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]
    class HARDWAREINPUT(ctypes.Structure):
        _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]
    class INPUT_UNION(ctypes.Union):
        _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]
    class INPUT(ctypes.Structure):
        _fields_ = [("type", wintypes.DWORD), ("union", INPUT_UNION)]

VK = {"ESC": 0x1B, "TAB": 0x09, "CAPS": 0x14, "ENTER": 0x0D, "SHIFT": 0x10,
      "CTRL": 0x11, "ALT": 0x12, "SPACE": 0x20, "BS": 0x08, "WIN": 0x5B, "MENU": 0x5D}
for i in range(1, 13):
    VK[f"F{i}"] = 0x70 + i - 1
for c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789":
    VK[c] = ord(c)
VK_TO_LABEL = {v: k for k, v in VK.items()}

def _app_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))

CONFIG_PATH = os.path.join(_app_dir(), "config.json")

INJECT_MAGIC = 0xE6A11E00


class StickyEngine:
    def __init__(self):
        self.master = True
        self.sticky = {}
        self._block_labels = set()
        self.s1_key = None
        self.s1_delay = 50
        self.s1_on = True
        self.s2_key = None
        self.s2_delay = 50
        self.s2_on = True
        self.combos = {
            "c1": {"key": None, "on": True, "seq": ["F", "1", "C"]},
            "c2": {"key": None, "on": True, "seq": ["F", "Z"]},
            "c3": {"key": None, "on": True, "seq": ["LBUTTON", "1", "C"]},
        }
        self.combo_gap = 40
        self.running = True
        self.fired = 0
        self._lock = threading.Lock()
        self._phys = {}
        self._side1 = False
        self._side2 = False
        self._mid = False
        self._last = {}
        self._combo_busy = False
        self._combo_edge = {}
        self.virtual_held = set()  # keys treated as held (side spam / inject)
        self._side_key_down = {}  # side -> currently held inject key
        self._kb_proc = self._ms_proc = None
        self._kh = self._mh = None
        # distance detect settings (filled by apply / config)
        self.distance = {
            "enabled": False,
            "threshold": 20.0,
            "mode_key": "z",
            "require_r": True,
            "burst": 5,
            "cooldown_ms": 500,
        }

    def _name(self, label):
        m = {"ESC": "esc", "TAB": "tab", "CAPS": "caps lock", "ENTER": "enter",
             "SHIFT": "shift", "CTRL": "ctrl", "ALT": "alt", "SPACE": "space",
             "BS": "backspace", "WIN": "windows", "MENU": "menu"}
        if label in m:
            return m[label]
        if len(label) == 1:
            return label.lower()
        if label.startswith("F") and label[1:].isdigit():
            return label.lower()
        return label.lower()

    def start(self):
        if HAVE_CTYPES:
            self._start_hooks()
            threading.Thread(target=self._poll_mouse, daemon=True).start()
        threading.Thread(target=self._loop, daemon=True).start()

    def _poll_mouse(self):
        """Always poll XBUTTON/MBUTTON — more reliable than hook alone under webview."""
        while self.running:
            try:
                s1 = bool(user32.GetAsyncKeyState(VK_XBUTTON1) & 0x8000) or bool(user32.GetKeyState(VK_XBUTTON1) & 0x8000)
                s2 = bool(user32.GetAsyncKeyState(VK_XBUTTON2) & 0x8000) or bool(user32.GetKeyState(VK_XBUTTON2) & 0x8000)
                md = bool(user32.GetAsyncKeyState(VK_MBUTTON) & 0x8000) or bool(user32.GetKeyState(VK_MBUTTON) & 0x8000)
                self._side1 = s1
                self._side2 = s2
                self._mid = md
            except Exception:
                pass
            time.sleep(0.001)

    def _start_hooks(self):
        HOOKPROC = CFUNCTYPE(ctypes.c_long, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
        eng = self

        @HOOKPROC
        def kb(nCode, wParam, lParam):
            if nCode == HC_ACTION:
                kbh = ctypes.cast(lParam, POINTER(KBDLLHOOKSTRUCT)).contents
                our = (int(kbh.dwExtraInfo) & 0xFFFFFFFF) == (INJECT_MAGIC & 0xFFFFFFFF)
                injected = bool(kbh.flags & LLKHF_INJECTED) or our
                vk = kbh.vkCode & 0xFF
                lab = VK_TO_LABEL.get(vk)
                if not injected and lab:
                    if wParam in (WM_KEYDOWN, WM_SYSKEYDOWN):
                        eng._phys[lab] = True
                    elif wParam in (WM_KEYUP, WM_SYSKEYUP):
                        eng._phys[lab] = False
                if (not injected) and eng.master and lab and lab in eng._block_labels:
                    return 1
            return user32.CallNextHookEx(None, nCode, wParam, lParam)

        @HOOKPROC
        def ms(nCode, wParam, lParam):
            if nCode == HC_ACTION:
                msh = ctypes.cast(lParam, POINTER(MSLLHOOKSTRUCT)).contents
                if wParam in (WM_XBUTTONDOWN, WM_XBUTTONUP):
                    xb = (msh.mouseData >> 16) & 0xFFFF
                    down = wParam == WM_XBUTTONDOWN
                    if xb == 1:
                        eng._side1 = down
                    elif xb == 2:
                        eng._side2 = down
                elif wParam in (WM_MBUTTONDOWN, WM_MBUTTONUP):
                    eng._mid = (wParam == WM_MBUTTONDOWN)
            return user32.CallNextHookEx(None, nCode, wParam, lParam)

        self._kb_proc, self._ms_proc = kb, ms
        self._kh = user32.SetWindowsHookExW(WH_KEYBOARD_LL, kb, None, 0) or user32.SetWindowsHookExW(
            WH_KEYBOARD_LL, kb, kernel32.GetModuleHandleW(None), 0)
        self._mh = user32.SetWindowsHookExW(WH_MOUSE_LL, ms, None, 0) or user32.SetWindowsHookExW(
            WH_MOUSE_LL, ms, kernel32.GetModuleHandleW(None), 0)

        def pump():
            msg = wintypes.MSG()
            while self.running:
                while user32.PeekMessageW(byref(msg), None, 0, 0, 1):
                    user32.TranslateMessage(byref(msg))
                    user32.DispatchMessageW(byref(msg))
                time.sleep(0.003)
            if self._kh:
                user32.UnhookWindowsHookEx(self._kh)
            if self._mh:
                user32.UnhookWindowsHookEx(self._mh)

        threading.Thread(target=pump, daemon=True).start()

    def _held(self, label):
        if label in ("XBUTTON1", "SIDE1", "MOUSE4"):
            return bool(self._side1)
        if label in ("XBUTTON2", "SIDE2", "MOUSE5"):
            return bool(self._side2)
        if label in ("MBUTTON", "MIDDLE", "MOUSE3"):
            return bool(self._mid) or (HAVE_CTYPES and bool(user32.GetAsyncKeyState(VK_MBUTTON) & 0x8000))
        if label == "LBUTTON":
            return HAVE_CTYPES and bool(user32.GetAsyncKeyState(0x01) & 0x8000)
        lab = str(label)
        if lab in self._phys:
            return bool(self._phys[lab])
        up = lab.upper()
        if up in self._phys:
            return bool(self._phys[up])
        if keyboard is None:
            return False
        try:
            if keyboard.is_pressed(self._name(up)):
                return True
            if up.startswith("F") and up[1:].isdigit():
                return bool(keyboard.is_pressed(up.lower()))
            return bool(keyboard.is_pressed(lab.lower()))
        except Exception:
            return False


    def _vk(self, label):
        if not label:
            return None
        lab = str(label).upper().strip()
        if lab in VK:
            return VK[lab]
        if len(lab) == 1:
            return ord(lab)
        return None

    def _send_key(self, label):
        # Match Personal sticky: keyboard.send (hold-to-spam stable)
        if label == "LBUTTON":
            if HAVE_CTYPES:
                for flags in (MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP):
                    inp = INPUT()
                    inp.type = 0
                    inp.union.mi = MOUSEINPUT(0, 0, 0, flags, 0, 0)
                    user32.SendInput(1, byref(inp), ctypes.sizeof(INPUT))
                self.fired += 1
            return
        if keyboard is None:
            return
        try:
            lab = str(label)
            keyboard.send(self._name(lab.upper() if len(lab) == 1 else lab))
            self.fired += 1
        except Exception:
            try:
                keyboard.send(self._name(label))
                self.fired += 1
            except Exception:
                pass


    def _key_down(self, label):
        if not label or not HAVE_CTYPES:
            return
        vk = self._vk(label)
        if vk is None:
            return
        try:
            scan = user32.MapVirtualKeyW(vk, 0) & 0xFF
            KEYEVENTF_SCANCODE = 0x0008
            inp = INPUT()
            inp.type = 1
            inp.union.ki = KEYBDINPUT(0, scan, KEYEVENTF_SCANCODE, 0, INJECT_MAGIC)
            user32.SendInput(1, byref(inp), ctypes.sizeof(INPUT))
        except Exception:
            pass

    def _key_up(self, label):
        if not label or not HAVE_CTYPES:
            return
        vk = self._vk(label)
        if vk is None:
            return
        try:
            scan = user32.MapVirtualKeyW(vk, 0) & 0xFF
            KEYEVENTF_SCANCODE = 0x0008
            KEYEVENTF_KEYUP = 0x0002
            inp = INPUT()
            inp.type = 1
            inp.union.ki = KEYBDINPUT(0, scan, KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP, 0, INJECT_MAGIC)
            user32.SendInput(1, byref(inp), ctypes.sizeof(INPUT))
        except Exception:
            pass

    def is_virtual_held(self, label):
        if not label:
            return False
        return str(label).upper() in self.virtual_held
    def _play_combo(self, seq, gap_ms):
        if self._combo_busy:
            return
        self._combo_busy = True

        def run():
            try:
                for i, step in enumerate(seq):
                    self._send_key(step)
                    if i < len(seq) - 1:
                        time.sleep(max(10, gap_ms) / 1000.0)
            finally:
                self._combo_busy = False

        threading.Thread(target=run, daemon=True).start()

    def _loop(self):
        while self.running:
            try:
                with self._lock:
                    master = self.master
                    sticky = dict(self.sticky)
                    s1k, s1d, s1on = self.s1_key, self.s1_delay, self.s1_on
                    s2k, s2d, s2on = self.s2_key, self.s2_delay, self.s2_on
                    combos = {k: dict(v) for k, v in self.combos.items()}
                    gap = self.combo_gap
                if not master:
                    time.sleep(0.01)
                    continue
                now = time.perf_counter()
                for label, dms in sticky.items():
                    interval = max(5, int(dms)) / 1000.0
                    if not self._held(label):
                        self._last.pop("k:" + label, None)
                        continue
                    k = "k:" + label
                    if now - self._last.get(k, 0) >= interval:
                        self._send_key(label)
                        self._last[k] = now
                # Side buttons: hold side -> spam bound key; mark virtual held for distance
                virt = set()
                def side_tick(on, key, delay, tag, held_flag):
                    if on and key and held_flag:
                        virt.add(str(key).upper())
                        # keep key physically down while side held (distance require_r / game)
                        if self._side_key_down.get(tag) != key:
                            self._key_up(self._side_key_down.get(tag))
                            self._key_down(key)
                            self._side_key_down[tag] = key
                        interval = max(1, int(delay)) / 1000.0
                        if now - self._last.get(tag, 0) >= interval:
                            self._send_key(key)
                            self._last[tag] = now
                    else:
                        self._last.pop(tag, None)
                        if self._side_key_down.get(tag):
                            self._key_up(self._side_key_down.get(tag))
                            self._side_key_down[tag] = None
                side_tick(s1on, s1k, s1d, "s1", self._side1)
                side_tick(s2on, s2k, s2d, "s2", self._side2)
                self.virtual_held = virt
                for cid, cfg in combos.items():
                    if not cfg.get("on") or not cfg.get("key"):
                        self._combo_edge[cid] = False
                        self._last.pop("combo:" + cid, None)
                        continue
                    down = self._held(cfg["key"])
                    # hold-to-spam: while bind held, replay combo after each finish
                    if down:
                        # small pause between loop cycles (reuse gap)
                        k = "combo:" + cid
                        if not self._combo_busy:
                            last = self._last.get(k, 0)
                            if now - last >= max(10, gap) / 1000.0:
                                self._play_combo(cfg.get("seq") or [], gap)
                                self._last[k] = now
                    else:
                        self._last.pop("combo:" + cid, None)
                    self._combo_edge[cid] = down
            except Exception:
                pass
            time.sleep(0.001)

    def apply(self, data):
        with self._lock:
            self.master = bool(data.get("master", True))
            self.sticky = {}
            block = set()
            for k, v in (data.get("sticky") or {}).items():
                try:
                    self.sticky[str(k)] = max(1, min(5000, int(v)))
                except Exception:
                    self.sticky[str(k)] = 50
                block.add(str(k))
            self._block_labels = block
            s1 = data.get("side1") or {}
            s2 = data.get("side2") or {}
            def _norm_key(k):
                if k in (None, "NONE", ""):
                    return None
                k = str(k).strip().upper()
                if k in ("XBUTTON1", "SIDE1", "MOUSE4"):
                    return None  # side cannot spam itself as key
                if k in ("XBUTTON2", "SIDE2", "MOUSE5"):
                    return None
                return k
            self.s1_key = _norm_key(s1.get("key"))
            self.s2_key = _norm_key(s2.get("key"))
            try:
                self.s1_delay = max(1, int(s1.get("delay", 50)))
            except Exception:
                pass
            try:
                self.s2_delay = max(1, int(s2.get("delay", 50)))
            except Exception:
                pass
            self.s1_on = bool(s1.get("on", True))
            self.s2_on = bool(s2.get("on", True))
            incoming = data.get("combos") or {}
            for cid in ("c1", "c2", "c3"):
                if cid in incoming:
                    src = incoming[cid] or {}
                    self.combos[cid]["key"] = src.get("key") if src.get("key") not in (None, "NONE", "") else None
                    self.combos[cid]["on"] = bool(src.get("on", True))
                    if src.get("seq"):
                        self.combos[cid]["seq"] = list(src["seq"])
            try:
                self.combo_gap = max(10, min(500, int(data.get("comboGap", 40))))
            except Exception:
                pass
            if "distance" in data and isinstance(data["distance"], dict):
                self.distance.update(data["distance"])

    def save_config(self, data):
        try:
            path = CONFIG_PATH
            d = os.path.dirname(path)
            if d:
                os.makedirs(d, exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            return path
        except Exception as e:
            return "ERR:" + str(e)

    def load_config(self):
        try:
            if not os.path.isfile(CONFIG_PATH):
                return None
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None
