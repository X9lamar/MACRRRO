Eclipse SpamKey — Z Boost side/middle bind fix

IMPORTANT (EXE):
1. Old EXE does NOT have the bind fix. You must rebuild.
2. Double-click build_exe.bat (needs Python + pip)
3. Run dist\EclipseSpamKey.exe AS ADMINISTRATOR
4. Open Roblox first
5. Z BOOST tab -> Enable -> click + -> press SIDE1 / SIDE2 / MIDDLE
6. STATUS should show: ready · bind=XBUTTON1
7. Hold side button -> STATUS: bind held / BOOSTING

If window never opens, check:
  %TEMP%\eclipse_spam_crash.log

python app.py also works (admin CMD).
