@echo off
cd /d "%~dp0"
:: Prefer rebuilt EXE
if exist "dist\EclipseSpamKey.exe" (
  echo Starting dist\EclipseSpamKey.exe as Admin...
  powershell -Command "Start-Process -FilePath '%~dp0dist\EclipseSpamKey.exe' -Verb RunAs"
  exit /b 0
)
if exist "EclipseSpamKey.exe" (
  powershell -Command "Start-Process -FilePath '%~dp0EclipseSpamKey.exe' -Verb RunAs"
  exit /b 0
)
echo No EXE found. Building...
call build_exe.bat
if exist "dist\EclipseSpamKey.exe" (
  powershell -Command "Start-Process -FilePath '%~dp0dist\EclipseSpamKey.exe' -Verb RunAs"
)
