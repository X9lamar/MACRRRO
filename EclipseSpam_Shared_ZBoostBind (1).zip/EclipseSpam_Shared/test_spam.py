"""Quick test: enables R sticky at 30ms. Hold R in Notepad. Ctrl+C quit."""
import time
from engine_core import StickyEngine, VK

eng = StickyEngine()
eng.start_hooks()
eng.apply_state({"master": True, "sticky": {"R": 30}, "side1": {"key": None, "delay": 50, "on": False}, "side2": {"key": None, "delay": 50, "on": False}})
print("Sticky R @ 30ms ON. Hold R in Notepad. Ctrl+C to exit.")
print("Hook OK. Fired counter will print every second.")
try:
    while True:
        time.sleep(1)
        print("fired", eng.fired, "phys_R", eng.phys[VK["R"]])
except KeyboardInterrupt:
    eng.running = False
    print("bye")
