import json, time, threading, sys, os

try:
    import webview
except ImportError:
    print("pip install pywebview"); input(); sys.exit(1)

from engine_core import StickyEngine, CONFIG_PATH

try:
    from distance_detect import DistanceDetect, AntiSoru
except Exception:
    DistanceDetect = None
    AntiSoru = None

try:
    from z_boost import ZBoost
    _ZBOOST_IMPORT_ERR = None
except Exception as e:
    ZBoost = None
    _ZBOOST_IMPORT_ERR = str(e)

eng = StickyEngine()
dist = DistanceDetect(on_status=lambda s: setattr(dist, "status", s)) if DistanceDetect else None
if dist:
    dist.r_check = lambda: eng.is_virtual_held("R") or eng.is_virtual_held("r")
    dist.status = "idle"

anti = AntiSoru(on_status=lambda s: setattr(anti, "status", s)) if AntiSoru else None
# do NOT start anti/zboost at import — wait until window up (EXE was freezing)

zboost = ZBoost(
    on_status=lambda s: setattr(zboost, "status", s),
    is_bind_held=lambda lab: eng._held(lab) if hasattr(eng, "_held") else False,
) if ZBoost else None
if zboost:
    zboost.status = "idle"


class Api:
    def update_state(self, js):
        try:
            data = json.loads(js)
            eng.apply(data)
            if dist and isinstance(data.get("distance"), dict):
                dist.configure(data["distance"])
                if data["distance"].get("enabled") and not dist.running:
                    dist.start()
                if not data["distance"].get("enabled") and dist.running:
                    dist.stop()
            if anti and isinstance(data.get("anti_soru"), dict):
                anti.configure(data["anti_soru"])
                if not anti.running:
                    anti.start()
            if zboost and isinstance(data.get("zboost"), dict):
                zboost.configure(data["zboost"])
                if not zboost.running:
                    zboost.start()
        except Exception as e:
            return str(e)
        return "ok"

    def save_config(self, js):
        try:
            data = json.loads(js)
            return str(eng.save_config(data))
        except Exception as e:
            return "ERR:" + str(e)

    def load_config(self):
        data = eng.load_config()
        return json.dumps(data) if data else ""

    def get_fired(self):
        return eng.fired

    def get_dist_status(self):
        return getattr(dist, "status", "n/a") if dist else "module missing"

    def get_zboost_status(self):
        if not zboost:
            return str(_ZBOOST_IMPORT_ERR or "module missing")[:60]
        return "%s #%s" % (getattr(zboost, "status", "?"), getattr(zboost, "boost_count", 0))

    def get_anti_status(self):
        if not anti:
            return "module missing"
        return "%s #%s" % (getattr(anti, "status", "?"), getattr(anti, "fired", 0))

    def ping(self):
        return "pong"


def main():
    api = Api()
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    html = os.path.join(base, "index.html")
    if not os.path.isfile(html):
        html = os.path.join(os.path.dirname(os.path.abspath(__file__)), "index.html")

    window = webview.create_window(
        "Eclipse SpamKey", url=html, js_api=api,
        width=1000, height=900, background_color="#0c0e14", min_size=(800, 600),
    )

    def on_start():
        def boot():
            eng.start()
            try:
                if zboost and not zboost.running:
                    zboost.start()
            except Exception:
                pass
            try:
                if anti and not anti.running:
                    anti.start()
            except Exception:
                pass
            cfg = eng.load_config()
            if cfg:
                try:
                    window.evaluate_js(
                        "window.applyConfig && window.applyConfig(%s)" % json.dumps(cfg)
                    )
                except Exception:
                    pass
            while eng.running:
                try:
                    js = window.evaluate_js("window.getState ? window.getState() : null")
                    if js:
                        data = json.loads(js)
                        eng.apply(data)
                        if dist and isinstance(data.get("distance"), dict):
                            dist.configure(data["distance"])
                            if data["distance"].get("enabled") and not dist.running:
                                dist.start()
                            if not data["distance"].get("enabled") and dist.running:
                                dist.stop()
                        if anti and isinstance(data.get("anti_soru"), dict):
                            anti.configure(data["anti_soru"])
                            if not anti.running:
                                anti.start()
                        if zboost and isinstance(data.get("zboost"), dict):
                            zboost.configure(data["zboost"])
                            if not zboost.running:
                                zboost.start()
                except Exception:
                    pass
                try:
                    st = api.get_dist_status()
                    zb = api.get_zboost_status()
                    an = api.get_anti_status()
                    window.evaluate_js(
                        "(function(){var e=document.getElementById('status');"
                        "if(e){var b=e.dataset.base||'Ready';e.textContent=b+' · d:'+%s+' · zb:'+%s+' · a:'+%s+' · f %d';}"
                        "var z=document.getElementById('zbStatusLabel'); if(z) z.textContent='STATUS: '+%s;"
                        "var a=document.getElementById('antiStatusLabel'); if(a) a.textContent='STATUS: '+%s;"
                        "})()"
                        % (
                            json.dumps(str(st)[:28]),
                            json.dumps(str(zb)[:24]),
                            json.dumps(str(an)[:24]),
                            eng.fired,
                            json.dumps(str(zb)),
                            json.dumps(str(an)),
                        )
                    )
                except Exception:
                    pass
                time.sleep(0.3)
        threading.Thread(target=boot, daemon=True).start()

    webview.start(func=on_start)
    eng.running = False
    if dist:
        dist.stop()
    if anti:
        anti.stop()
    if zboost:
        try:
            zboost.stop()
        except Exception:
            pass

if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        log = os.path.join(os.environ.get("TEMP", "."), "eclipse_spam_crash.log")
        try:
            open(log, "a", encoding="utf-8").write(traceback.format_exc() + "\n")
        except Exception:
            pass
        raise
