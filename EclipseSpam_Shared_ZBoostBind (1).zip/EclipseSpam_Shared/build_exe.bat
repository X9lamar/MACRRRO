@echo off
cd /d "%~dp0"
echo [1] Installing deps...
py -m pip install -U pywebview keyboard pyinstaller
echo [2] Building EXE (onefile + admin)...
py -m PyInstaller --noconfirm --clean --onefile --windowed --uac-admin ^
  --name EclipseSpamKey ^
  --icon EclipseSpamKey.ico ^
  --add-data "index.html;." ^
  --hidden-import z_boost ^
  --hidden-import distance_detect ^
  --hidden-import engine_core ^
  --hidden-import keyboard ^
  --collect-all keyboard ^
  app.py
if errorlevel 1 (
  echo BUILD FAILED
  pause
  exit /b 1
)
echo.
echo OK: dist\EclipseSpamKey.exe
echo Right-click - Run as administrator
echo Open Roblox first, then enable Z Boost and bind SIDE1/SIDE2/MIDDLE
pause
