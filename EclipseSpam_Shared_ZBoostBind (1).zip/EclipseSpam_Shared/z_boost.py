"""Z Boost — EXACT port of engine.py BoostModule (Sanguine Z).

Do not diverge from engine.py velocity / Z-hold logic.
"""
import ctypes
import ctypes.wintypes as wintypes
import json
import math
import struct
import time
import threading
import urllib.request

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
ntdll = ctypes.WinDLL("ntdll", use_last_error=True)
user32 = ctypes.WinDLL("user32", use_last_error=True)

PROCESS_ACCESS = 0x1F0FFF
TH32CS_SNAPMODULE = 0x08
TH32CS_SNAPPROCESS = 0x02

class MODULEENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD), ("th32ModuleID", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD), ("GlblcntUsage", wintypes.DWORD),
        ("ProccntUsage", wintypes.DWORD), ("modBaseAddr", ctypes.POINTER(ctypes.c_byte)),
        ("modBaseSize", wintypes.DWORD), ("hModule", wintypes.HMODULE),
        ("szModule", ctypes.c_wchar * 256), ("szExePath", ctypes.c_wchar * 260),
    ]

class PROCESSENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD), ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
        ("th32ModuleID", wintypes.DWORD), ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD), ("pcPriClassBase", ctypes.c_long),
        ("dwFlags", wintypes.DWORD), ("szExeFile", ctypes.c_wchar * 260),
    ]

# --- from engine.py (defaults fixed so PrimVelocity is never 0) ---
OFFSETS = {
    "FakeDataModelPtr": 0x8F59810, "RealDataModel": 0x1F8,
    "ChildrenStart": 0x70, "ChildrenEnd": 0x8,
    "NameContainer": 0x68, "Name": 0,
    "Workspace": 0x148, "LocalPlayer": 0x118,
    "ModelInstance": 0x290, "HumanoidRootPart": 0x460,
    "Primitive": 0x178, "PrimitivePosition": 0xD4,
    "StringLength": 16,
    "PrimVelocity": 0xE0,
    "DMWorkspace": 0x148, "WSCamera": 0x4A0, "CamRotation": 0xC0,
}

def auto_update_offsets():
    try:
        req = urllib.request.Request(
            "https://offsets.imtheo.lol/offsets.json",
            headers={"User-Agent": "Mozilla/5.0 Eclipse/1.0"},
        )
        with urllib.request.urlopen(req, timeout=3) as r:
            j = json.loads(r.read().decode("utf-8", errors="ignore"))
        root = j.get("Offsets") if isinstance(j.get("Offsets"), dict) else j

        def g(sec, key, fb):
            try:
                sec_obj = root.get(sec, {}) if isinstance(root, dict) else {}
                v = sec_obj.get(key, 0)
                v = int(v) if v is not None else 0
                return v if v > 0 or (v == 0 and key in ("Name", "ChildrenEnd")) else fb
            except Exception:
                return fb

        OFFSETS["FakeDataModelPtr"] = g("FakeDataModel", "Pointer", OFFSETS["FakeDataModelPtr"])
        OFFSETS["RealDataModel"] = g("FakeDataModel", "RealDataModel", OFFSETS["RealDataModel"])
        OFFSETS["ChildrenStart"] = g("Instance", "ChildrenStart", OFFSETS["ChildrenStart"])
        OFFSETS["ChildrenEnd"] = g("Instance", "ChildrenEnd", OFFSETS["ChildrenEnd"])
        OFFSETS["Name"] = g("Instance", "Name", OFFSETS["Name"])
        OFFSETS["NameContainer"] = g("Instance", "NameContainer", OFFSETS["NameContainer"])
        OFFSETS["LocalPlayer"] = g("Player", "LocalPlayer", OFFSETS["LocalPlayer"])
        OFFSETS["ModelInstance"] = g("Player", "ModelInstance", OFFSETS["ModelInstance"])
        OFFSETS["HumanoidRootPart"] = g("Humanoid", "HumanoidRootPart", OFFSETS["HumanoidRootPart"])
        OFFSETS["Primitive"] = g("BasePart", "Primitive", OFFSETS["Primitive"])
        OFFSETS["PrimitivePosition"] = g("Primitive", "Position", OFFSETS["PrimitivePosition"])
        OFFSETS["StringLength"] = g("Misc", "StringLength", OFFSETS["StringLength"])
        OFFSETS["PrimVelocity"] = g("Primitive", "AssemblyLinearVelocity", OFFSETS["PrimVelocity"])
        if not OFFSETS["PrimVelocity"]:
            OFFSETS["PrimVelocity"] = g("Primitive", "Velocity", OFFSETS["PrimVelocity"]) or 0xE0
        OFFSETS["DMWorkspace"] = g("DataModel", "Workspace", OFFSETS["DMWorkspace"]) or 0x148
        OFFSETS["WSCamera"] = g("Workspace", "CurrentCamera", OFFSETS["WSCamera"]) or 0x4A0
        OFFSETS["CamRotation"] = g("Camera", "Rotation", OFFSETS["CamRotation"]) or 0xC0
        OFFSETS["Workspace"] = OFFSETS["DMWorkspace"]
    except Exception:
        pass
    # never leave critical zeros
    if not OFFSETS.get("PrimVelocity"):
        OFFSETS["PrimVelocity"] = 0xE0
    if not OFFSETS.get("DMWorkspace"):
        OFFSETS["DMWorkspace"] = 0x148
    if not OFFSETS.get("WSCamera"):
        OFFSETS["WSCamera"] = 0x4A0
    if not OFFSETS.get("CamRotation"):
        OFFSETS["CamRotation"] = 0xC0

def find_pid():
    snap = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if snap in (0, -1): return 0
    pe = PROCESSENTRY32W()
    pe.dwSize = ctypes.sizeof(PROCESSENTRY32W)
    ok = kernel32.Process32FirstW(snap, ctypes.byref(pe))
    names = ("robloxplayerbeta.exe", "windows10universal.exe")
    while ok:
        if (pe.szExeFile or "").lower() in names:
            pid = pe.th32ProcessID
            kernel32.CloseHandle(snap)
            return pid
        ok = kernel32.Process32NextW(snap, ctypes.byref(pe))
    kernel32.CloseHandle(snap)
    return 0


class Memory:
    def __init__(self, pid):
        self.pid = pid
        self.h = kernel32.OpenProcess(PROCESS_ACCESS, False, pid)
        if not self.h: raise OSError("OpenProcess failed — run as Admin")
        self.base = self._module_base()

    def close(self):
        if getattr(self, "h", 0): kernel32.CloseHandle(self.h); self.h = 0

    def alive(self):
        if not self.h: return False
        code = wintypes.DWORD()
        return kernel32.GetExitCodeProcess(self.h, ctypes.byref(code)) and code.value == 259

    def _module_base(self):
        snap = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, self.pid)
        if snap in (-1, 0): return 0
        me = MODULEENTRY32W(); me.dwSize = ctypes.sizeof(MODULEENTRY32W)
        ok = kernel32.Module32FirstW(snap, ctypes.byref(me))
        base = ctypes.cast(me.modBaseAddr, ctypes.c_void_p).value if ok else 0
        kernel32.CloseHandle(snap)
        return base or 0

    def read(self, addr, typ="UInt64"):
        if not addr: return 0
        size = 4 if typ in ("Float", "UInt", "Int") else 8
        buf = (ctypes.c_byte * size)()
        ntdll.NtReadVirtualMemory(self.h, ctypes.c_void_p(addr), buf, size, None)
        raw = bytes(buf)
        if typ == "Float": return ctypes.c_float.from_buffer_copy(raw).value
        if typ in ("UInt", "Int"): return int.from_bytes(raw, "little", signed=(typ == "Int"))
        return int.from_bytes(raw, "little")

    def read_string(self, addr):
        if not addr: return ""
        try:
            length = self.read(addr + OFFSETS.get("StringLength", 16), "Int")
            if length <= 0 or length > 200: return ""
            if length >= 16: addr = self.read(addr, "UInt64")
            if not addr: return ""
            buf = (ctypes.c_char * (length + 1))()
            ntdll.NtReadVirtualMemory(self.h, ctypes.c_void_p(addr), buf, length, None)
            return bytes(buf).split(b"\x00", 1)[0].decode("utf-8", errors="ignore")
        except: return ""

    def write(self, addr, data):
        if not addr or not self.h: return False
        written = ctypes.c_size_t(0)
        ok = kernel32.WriteProcessMemory(self.h, ctypes.c_void_p(addr), data, len(bytes(data)), ctypes.byref(written))
        return bool(ok) and written.value == len(bytes(data))


# ---------------------------------------------------------------------------
# Traversal Helpers
# ---------------------------------------------------------------------------
def _inst_name(mem, inst):
    if not inst: return ""
    nc = mem.read(inst + OFFSETS.get("NameContainer", 104))
    if nc:
        s = mem.read_string(nc)
        if s: return s
    np = mem.read(inst + OFFSETS.get("Name", 0))
    if np and np > 0x10000: return mem.read_string(np)
    return ""

def _children(mem, inst):
    out = []
    if not inst: return out
    ptr = mem.read(inst + OFFSETS["ChildrenStart"])
    if not ptr: return out
    start = mem.read(ptr)
    end = mem.read(ptr + OFFSETS["ChildrenEnd"])
    if not start or not end or end < start: return out
    cur = start
    for _ in range(400):
        if cur >= end: break
        child = mem.read(cur)
        if child and child != inst: out.append(child)
        cur += 0x10
    return out

def _find_child(mem, inst, name):
    for c in _children(mem, inst):
        if _inst_name(mem, c) == name: return c
    return 0

def _datamodel(mem):
    fake = mem.read(mem.base + OFFSETS["FakeDataModelPtr"])
    return mem.read(fake + OFFSETS["RealDataModel"]) if fake else 0

def _players(mem, dm):
    return _find_child(mem, dm, "Players") if dm else 0

def _local_char(mem, dm):
    pl = _players(mem, dm)
    if not pl: return 0, 0
    lp = mem.read(pl + OFFSETS["LocalPlayer"])
    return (mem.read(lp + OFFSETS["ModelInstance"]), lp) if lp else (0, 0)

def _root_part(mem, char):
    if not char: return 0
    hrp = _find_child(mem, char, "HumanoidRootPart")
    if hrp: return hrp
    hum = _find_child(mem, char, "Humanoid")
    if hum and OFFSETS.get("HumanoidRootPart"):
        rp = mem.read(hum + OFFSETS["HumanoidRootPart"])
        if rp > 0x10000: return rp
    return 0



# ---------------------------------------------------------------------------
# BoostModule EXACT from engine.py — class name ZBoost for SpamKey import
# ---------------------------------------------------------------------------
class ZBoost:
    def __init__(self, on_status=None, is_bind_held=None, log_cb=None):
        # SpamKey passes on_status=; engine uses log_cb=
        self.log_cb = log_cb or (lambda src, msg: None)
        self.on_status = on_status
        self.is_bind_held = is_bind_held  # unused; engine uses GetAsyncKeyState/keyboard only
        self.running = False
        self.enabled = False
        self.power = 900.0
        self.lift = 180.0
        self.duration = 2.0
        self.cooldown_ms = 80
        self.bind = "xbutton1"
        self.boost_count = 0
        self.status = "idle"
        # SpamKey UI cfg mirror
        self.cfg = {
            "enabled": False,
            "bind": "xbutton1",
            "power": 900.0,
            "lift": 180.0,
            "duration_ms": 2000,
            "cooldown_ms": 80,
        }

    def _log(self, src, msg):
        try:
            self.log_cb(src, msg)
        except Exception:
            pass
        self.status = msg if len(msg) < 48 else msg[:48]
        if self.on_status:
            try:
                self.on_status(self.status)
            except Exception:
                pass

    def configure(self, d):
        """SpamKey UI -> same fields as engine BoostModule."""
        if not isinstance(d, dict):
            return
        if "enabled" in d:
            self.enabled = bool(d["enabled"])
            self.cfg["enabled"] = self.enabled
        if "bind" in d:
            self.bind = str(d["bind"]).lower()
            self.cfg["bind"] = self.bind
        if "power" in d:
            self.power = float(d["power"])
            self.cfg["power"] = self.power
        if "lift" in d:
            self.lift = float(d["lift"])
            self.cfg["lift"] = self.lift
        if "duration_ms" in d:
            self.duration = float(d["duration_ms"]) / 1000.0
            self.cfg["duration_ms"] = float(d["duration_ms"])
        if "dur" in d:
            self.duration = float(d["dur"]) / 1000.0
        if "cooldown_ms" in d:
            self.cooldown_ms = float(d["cooldown_ms"])
            self.cfg["cooldown_ms"] = self.cooldown_ms
        if "cd" in d:
            self.cooldown_ms = float(d["cd"])
        if self.enabled:
            if not self.running:
                self.start()
            if self.status in ("idle", "", None):
                self.status = "ready"
        else:
            self.status = "idle"

    def start(self):
        if not self.running:
            self.running = True
            # never block UI/EXE on network offsets
            threading.Thread(target=lambda: auto_update_offsets(), daemon=True).start()
            threading.Thread(target=self._loop, daemon=True).start()

    def stop(self):
        self.running = False


    def _loop(self):
        """Engine BoostModule math, no auto-Z; dense writes through skill anim."""
        try:
            import keyboard as kb
        except Exception:
            return
        user32 = ctypes.windll.user32
        mem = None
        last_fire = 0.0
        boost_active = False
        boost_end = 0.0
        vel = (0.0, 0.0, 0.0)
        last_push = 0.0
        key_down = False

        while self.running:
            if mem is None or not mem.alive():
                if mem:
                    try:
                        mem.close()
                    except Exception:
                        pass
                pid = find_pid()
                if not pid:
                    if self.enabled:
                        self.status = "wait roblox"
                    time.sleep(1.0)
                    continue
                try:
                    mem = Memory(pid)
                except Exception:
                    time.sleep(1.0)
                    continue
                self._log("Z Boost", "Attached to PID %s" % pid)
                self.status = "ready"
                key_down = boost_active = False

            try:
                if not self.enabled:
                    key_down = boost_active = False
                    self.status = "idle"
                    time.sleep(0.02)
                    continue

                if not boost_active:
                    self.status = "ready"

                down = False
                b_raw = str(self.bind or "xbutton1")
                b_lower = b_raw.lower().replace(" ", "").replace("_", "").replace("-", "")
                # Mouse binds — GetAsyncKeyState (keyboard lib cannot see X1/X2/M reliably)
                if b_lower in ("xbutton1", "mouse4", "side1", "xbtn1", "m4", "side", "s1"):
                    down = bool(user32.GetAsyncKeyState(0x05) & 0x8000)
                elif b_lower in ("xbutton2", "mouse5", "side2", "xbtn2", "m5", "s2"):
                    down = bool(user32.GetAsyncKeyState(0x06) & 0x8000)
                elif b_lower in ("mbutton", "middle", "mid", "mouse3", "m3", "mmb"):
                    down = bool(user32.GetAsyncKeyState(0x04) & 0x8000)
                elif b_lower in ("lbutton", "left", "lmb", "mouse1", "m1"):
                    down = bool(user32.GetAsyncKeyState(0x01) & 0x8000)
                elif b_lower in ("rbutton", "right", "rmb", "mouse2", "m2"):
                    down = bool(user32.GetAsyncKeyState(0x02) & 0x8000)
                elif "xbutton1" in b_lower or "mouse4" in b_lower:
                    down = bool(user32.GetAsyncKeyState(0x05) & 0x8000)
                elif "xbutton2" in b_lower or "mouse5" in b_lower:
                    down = bool(user32.GetAsyncKeyState(0x06) & 0x8000)
                else:
                    try:
                        # keyboard keys: G, Z, etc.
                        key = b_raw
                        if len(key) == 1:
                            down = bool(user32.GetAsyncKeyState(ord(key.upper())) & 0x8000)
                        else:
                            down = kb.is_pressed(key)
                    except Exception:
                        down = False

                if self.enabled and down and not boost_active:
                    self.status = "bind held (%s)" % (self.bind or "?")
                elif self.enabled and not boost_active:
                    self.status = "ready · bind=%s" % (self.bind or "?")

                now = time.time() * 1000

                if down and not key_down:
                    if now - last_fire > self.cooldown_ms:
                        dm = _datamodel(mem)
                        if dm:
                            ws_off = OFFSETS.get("DMWorkspace") or OFFSETS.get("Workspace") or 0
                            cam_off = OFFSETS.get("WSCamera") or OFFSETS.get("CurrentCamera") or 0
                            rot_off = OFFSETS.get("CamRotation") or 0
                            ws = mem.read(dm + ws_off) if ws_off else 0
                            cam = mem.read(ws + cam_off) if (ws and cam_off) else 0
                            lx, ly, lz = 0.0, 0.0, -1.0
                            if cam and rot_off:
                                rot = cam + rot_off
                                lx = -mem.read(rot + 8, "Float")
                                ly = -mem.read(rot + 20, "Float")
                                lz = -mem.read(rot + 32, "Float")
                            n = math.sqrt(lx * lx + ly * ly + lz * lz)
                            if n > 0.001:
                                lx, ly, lz = lx / n, ly / n, lz / n
                            # exact engine flatten
                            flat_len = math.sqrt(lx * lx + lz * lz)
                            fx, fz = (lx / flat_len, lz / flat_len) if flat_len > 0.001 else (0.0, -1.0)
                            vy = max(-180.0, min(320.0, ly * self.power * 0.5 + self.lift))
                            vel = (fx * self.power, vy, fz * self.power)

                            char, _ = _local_char(mem, dm)
                            hrp = _root_part(mem, char)
                            prim = mem.read(hrp + OFFSETS["Primitive"]) if hrp else 0
                            if not hrp:
                                self.status = "no HRP (offsets?)"
                            elif not prim:
                                self.status = "no Primitive"
                            elif prim:
                                buf = (ctypes.c_float * 3)(*vel)
                                vel_off = OFFSETS.get("PrimVelocity") or OFFSETS.get("AssemblyLinearVelocity") or 0xE0
                                ok = False
                                for _ in range(24):
                                    if mem.write(prim + vel_off, buf):
                                        ok = True
                                if ok:
                                    boost_active = True
                                    boost_end = now + self.duration * 1000
                                    last_fire = now
                                    last_push = now
                                    self.boost_count += 1
                                    self.status = "BOOSTING #%s" % self.boost_count
                                    self._log("Z Boost", "BOOSTING #%s" % self.boost_count)
                                else:
                                    self.status = "write fail"

                if down and boost_active:
                    boost_end = max(boost_end, now + 150.0)

                if boost_active:
                    if now >= boost_end and not down:
                        boost_active = False
                        if self.enabled:
                            self.status = "ready"
                    else:
                        dm = _datamodel(mem)
                        char, _ = _local_char(mem, dm) if dm else (0, 0)
                        hrp = _root_part(mem, char)
                        prim = mem.read(hrp + OFFSETS["Primitive"]) if hrp else 0
                        if prim:
                            buf = (ctypes.c_float * 3)(*vel)
                            vel_off = OFFSETS.get("PrimVelocity") or OFFSETS.get("AssemblyLinearVelocity") or 0xE0
                            for _ in range(16):
                                mem.write(prim + vel_off, buf)
                        last_push = now
                        key_down = down
                        time.sleep(0.001)
                        continue

                key_down = down
            except Exception as e:
                if mem:
                    try:
                        mem.close()
                    except Exception:
                        pass
                mem = None
                self.status = "err " + str(e)[:40]
                time.sleep(0.5)
            time.sleep(0.005)

