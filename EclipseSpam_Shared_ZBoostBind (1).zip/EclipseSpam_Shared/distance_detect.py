
"""Distance Detect — reconnects if Roblox starts after this tool."""
import ctypes
import ctypes.wintypes as wintypes
import json
import math
import time
import threading
import urllib.request

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
ntdll = ctypes.WinDLL("ntdll", use_last_error=True)

PROCESS_ACCESS = 0x1F0FFF
TH32CS_SNAPMODULE = 0x08
TH32CS_SNAPPROCESS = 0x02

class MODULEENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD), ("th32ModuleID", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD), ("GlblcntUsage", wintypes.DWORD),
        ("ProccntUsage", wintypes.DWORD), ("modBaseAddr", ctypes.POINTER(ctypes.c_byte)),
        ("modBaseSize", wintypes.DWORD), ("hModule", wintypes.HMODULE),
        ("szModule", ctypes.c_wchar * 256), ("szExePath", ctypes.c_wchar * 260),
    ]

class PROCESSENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD), ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
        ("th32ModuleID", wintypes.DWORD), ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD), ("pcPriClassBase", ctypes.c_long),
        ("dwFlags", wintypes.DWORD), ("szExeFile", ctypes.c_wchar * 260),
    ]

OFFSETS = {
    # LIVE defaults version-9ac8595712b447a7 (20/10/2026 theo dump) — auto-update overwrites on start
    "FakeDataModelPtr": 150312976,   # FakeDataModel.Pointer = 0x8F59810
    "RealDataModel": 504,            # FakeDataModel.RealDataModel = 0x1F8
    "ChildrenStart": 112,            # Instance.ChildrenStart = 0x70
    "ChildrenEnd": 8,                # Instance.ChildrenEnd
    "NameContainer": 104,            # Instance.NameContainer = 0x68
    "Name": 0,                       # Instance.Name
    "Workspace": 328,                # DataModel.Workspace = 0x148
    "LocalPlayer": 280,              # Player.LocalPlayer = 0x118
    "ModelInstance": 656,            # Player.ModelInstance = 0x290
    "HumanoidRootPart": 1120,        # Humanoid.HumanoidRootPart = 0x460
    "Primitive": 376,                # BasePart.Primitive = 0x178
    "PrimitivePosition": 212,        # Primitive.Position = 0xD4
    "StringLength": 16,              # Misc.StringLength
}


def auto_update_offsets():
    """Pull live offsets from theo. Handles nested Offsets{} JSON."""
    try:
        req = urllib.request.Request(
            "https://offsets.imtheo.lol/Offsets.json",
            headers={"User-Agent": "Mozilla/5.0 EclipseSpam/1.1"},
        )
        with urllib.request.urlopen(req, timeout=6) as r:
            j = json.loads(r.read().decode("utf-8", errors="ignore"))
        root = j.get("Offsets") if isinstance(j.get("Offsets"), dict) else j

        def g(sec, key, fb):
            try:
                sec_obj = root.get(sec, {}) if isinstance(root, dict) else {}
                if not isinstance(sec_obj, dict):
                    return fb
                v = sec_obj.get(key, 0)
                v = int(v) if v is not None else 0
                return v if v > 0 or (v == 0 and key in ("Name", "ChildrenEnd")) else fb
            except Exception:
                return fb

        OFFSETS["FakeDataModelPtr"] = g("FakeDataModel", "Pointer", OFFSETS["FakeDataModelPtr"])
        OFFSETS["RealDataModel"] = g("FakeDataModel", "RealDataModel", OFFSETS["RealDataModel"])
        OFFSETS["ChildrenStart"] = g("Instance", "ChildrenStart", OFFSETS["ChildrenStart"])
        OFFSETS["ChildrenEnd"] = g("Instance", "ChildrenEnd", OFFSETS["ChildrenEnd"])
        OFFSETS["Name"] = g("Instance", "Name", OFFSETS["Name"])
        OFFSETS["NameContainer"] = g("Instance", "NameContainer", OFFSETS["NameContainer"])
        OFFSETS["Workspace"] = g("DataModel", "Workspace", OFFSETS["Workspace"])
        OFFSETS["LocalPlayer"] = g("Player", "LocalPlayer", OFFSETS["LocalPlayer"])
        OFFSETS["ModelInstance"] = g("Player", "ModelInstance", OFFSETS["ModelInstance"])
        OFFSETS["HumanoidRootPart"] = g("Humanoid", "HumanoidRootPart", OFFSETS.get("HumanoidRootPart", 1120))
        OFFSETS["Primitive"] = g("BasePart", "Primitive", OFFSETS["Primitive"])
        OFFSETS["PrimitivePosition"] = g("Primitive", "Position", OFFSETS["PrimitivePosition"])
        OFFSETS["StringLength"] = g("Misc", "StringLength", OFFSETS.get("StringLength", 16))
        # optional status for UI
        try:
            ver = j.get("Roblox Version") or j.get("Version") or ""
            dumped = j.get("Dumped At") or ""
            OFFSETS["_meta_version"] = str(ver)
            OFFSETS["_meta_dumped"] = str(dumped)
        except Exception:
            pass
    except Exception:
        pass


def find_pid():
    snap = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if snap in (0, -1):
        return 0
    pe = PROCESSENTRY32W()
    pe.dwSize = ctypes.sizeof(PROCESSENTRY32W)
    ok = kernel32.Process32FirstW(snap, ctypes.byref(pe))
    names = ("robloxplayerbeta.exe", "windows10universal.exe")
    while ok:
        exe = (pe.szExeFile or "").lower()
        if exe in names:
            pid = pe.th32ProcessID
            kernel32.CloseHandle(snap)
            return pid
        ok = kernel32.Process32NextW(snap, ctypes.byref(pe))
    kernel32.CloseHandle(snap)
    return 0

class Memory:
    def __init__(self, pid):
        self.pid = pid
        self.h = kernel32.OpenProcess(PROCESS_ACCESS, False, pid)
        if not self.h:
            raise OSError("OpenProcess failed — run as Administrator")
        self.base = self._module_base()

    def close(self):
        if getattr(self, "h", 0):
            kernel32.CloseHandle(self.h)
            self.h = 0

    def alive(self):
        if not self.h:
            return False
        code = wintypes.DWORD()
        if kernel32.GetExitCodeProcess(self.h, ctypes.byref(code)):
            return code.value == 259
        return False

    def _module_base(self):
        snap = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, self.pid)
        if snap in (-1, 0):
            return 0
        me = MODULEENTRY32W()
        me.dwSize = ctypes.sizeof(MODULEENTRY32W)
        ok = kernel32.Module32FirstW(snap, ctypes.byref(me))
        base = ctypes.cast(me.modBaseAddr, ctypes.c_void_p).value if ok else 0
        kernel32.CloseHandle(snap)
        return base or 0

    def read(self, addr, typ="UInt64"):
        if not addr:
            return 0
        size = 4 if typ in ("Float", "UInt", "Int") else 8
        buf = (ctypes.c_byte * size)()
        ntdll.NtReadVirtualMemory(self.h, ctypes.c_void_p(addr), buf, size, None)
        raw = bytes(buf)
        if typ == "Float":
            return ctypes.c_float.from_buffer_copy(raw).value
        if typ in ("UInt", "Int"):
            return int.from_bytes(raw, "little", signed=(typ == "Int"))
        return int.from_bytes(raw, "little")

    def read_string(self, addr):
        if not addr:
            return ""
        try:
            length = self.read(addr + OFFSETS.get("StringLength", 16), "Int")
            if length <= 0 or length > 200:
                return ""
            if length >= 16:
                addr = self.read(addr, "UInt64")
            if not addr:
                return ""
            buf = (ctypes.c_char * (length + 1))()
            ntdll.NtReadVirtualMemory(self.h, ctypes.c_void_p(addr), buf, length, None)
            return bytes(buf).split(b"\x00", 1)[0].decode("utf-8", errors="ignore")
        except Exception:
            return ""

class DistanceDetect:
    def __init__(self, on_status=None):
        self.on_status = on_status or (lambda s: None)
        self.running = False
        self.threshold = 20.0
        self.mode_key = "z"
        self.require_r = True
        self.burst = 5
        self.cooldown_ms = 500
        self._thread = None
        self.status = "idle"
        self.r_check = None  # optional callback: () -> bool virtual R

    def configure(self, d):
        self.threshold = float(d.get("threshold", 20))
        self.mode_key = str(d.get("mode_key", "z")).lower()
        self.require_r = bool(d.get("require_r", True))
        self.burst = max(1, int(d.get("burst", 5)))
        self.cooldown_ms = max(50, int(d.get("cooldown_ms", 500)))

    def start(self):
        if self.running:
            return
        self.running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self.running = False

    def _set(self, s):
        self.status = s
        try:
            self.on_status(s)
        except Exception:
            pass

    def _attach(self):
        auto_update_offsets()
        while self.running:
            pid = find_pid()
            if not pid:
                self._set("Waiting for Roblox...")
                time.sleep(1.0)
                continue
            try:
                mem = Memory(pid)
                if not mem.base:
                    mem.close()
                    self._set("Roblox base=0, retry...")
                    time.sleep(1.0)
                    continue
                self._set("Attached PID %d | %s" % (pid, OFFSETS.get("_meta_version", "offsets ok")))
                return mem
            except Exception as e:
                self._set("Attach fail: %s" % e)
                time.sleep(1.5)
        return None

    def _loop(self):
        try:
            import keyboard as kb
        except ImportError:
            self._set("need keyboard pkg")
            self.running = False
            return
        mem = None
        last = None
        last_char = 0
        cooldown_until = 0
        while self.running:
            if mem is None or not mem.alive():
                if mem:
                    try:
                        mem.close()
                    except Exception:
                        pass
                mem = self._attach()
                last = None
                last_char = 0
                if not mem:
                    break
                self._set("RUNNING — hold R + Soru")
            try:
                pos, char = self._read_pos(mem)
                if not pos:
                    last = None
                    time.sleep(0.02)
                    continue
                if char and char != last_char:
                    last_char = char
                    last = None
                if last is None:
                    last = pos
                    time.sleep(0.001)
                    continue
                dist = math.sqrt((pos[0]-last[0])**2 + (pos[1]-last[1])**2 + (pos[2]-last[2])**2)
                now = time.time() * 1000
                r_phys = False
                try:
                    r_phys = kb.is_pressed("r")
                except Exception:
                    r_phys = False
                if not r_phys:
                    try:
                        import ctypes
                        r_phys = bool(ctypes.WinDLL("user32").GetAsyncKeyState(0x52) & 0x8000)
                    except Exception:
                        pass
                r_virt = False
                try:
                    if callable(self.r_check):
                        r_virt = bool(self.r_check())
                except Exception:
                    r_virt = False
                r_ok = (not self.require_r) or r_phys or r_virt
                if dist > self.threshold and r_ok and now >= cooldown_until:
                    cooldown_until = now + self.cooldown_ms
                    for _ in range(self.burst):
                        kb.send(self.mode_key)
                    self._set("FIRE %s dist=%.1f" % (self.mode_key.upper(), dist))
                last = pos
            except Exception:
                try:
                    mem.close()
                except Exception:
                    pass
                mem = None
                time.sleep(0.5)
                continue
            time.sleep(0.001)
        if mem:
            try:
                mem.close()
            except Exception:
                pass
        self._set("STOPPED")

    def _get_name(self, mem, inst):
        if not inst:
            return ""
        # Current layout: NameContainer at instance, then string object
        nc = mem.read(inst + OFFSETS.get("NameContainer", 112))
        if nc:
            # Name field may be the string object itself or offset inside
            s = mem.read_string(nc)
            if s:
                return s
            s = mem.read_string(nc + OFFSETS.get("Name", 8))
            if s:
                return s
        # fallback: direct Name pointer on instance
        np = mem.read(inst + OFFSETS.get("Name", 8))
        if np and np > 0x10000:
            return mem.read_string(np)
        return ""

    def _children(self, mem, inst):
        out = []
        if not inst:
            return out
        ptr = mem.read(inst + OFFSETS["ChildrenStart"])
        if not ptr:
            return out
        start = mem.read(ptr)
        end = mem.read(ptr + OFFSETS["ChildrenEnd"])
        if not start or not end or end < start:
            return out
        cur = start
        for _ in range(400):
            if cur >= end:
                break
            child = mem.read(cur)
            if child and child != inst:
                out.append(child)
            cur += 0x10
        return out

    def _find_child(self, mem, inst, name):
        for c in self._children(mem, inst):
            if self._get_name(mem, c) == name:
                return c
        return 0

    def _read_pos(self, mem):
        fake = mem.read(mem.base + OFFSETS["FakeDataModelPtr"])
        if not fake:
            return None, 0
        dm = mem.read(fake + OFFSETS["RealDataModel"])
        if not dm:
            return None, 0
        players = self._find_child(mem, dm, "Players")
        if not players:
            return None, 0
        lp = mem.read(players + OFFSETS["LocalPlayer"])
        if not lp:
            return None, 0
        char = mem.read(lp + OFFSETS["ModelInstance"])
        if not char:
            return None, 0
        hrp = self._find_child(mem, char, "HumanoidRootPart")
        if not hrp:
            # fallback: Character.Humanoid -> HumanoidRootPart offset
            hum = self._find_child(mem, char, "Humanoid")
            if hum:
                hrp = mem.read(hum + OFFSETS.get("HumanoidRootPart", 1128))
        if not hrp:
            return None, 0
        prim = mem.read(hrp + OFFSETS["Primitive"])
        if not prim:
            return None, 0
        base = prim + OFFSETS["PrimitivePosition"]
        x = mem.read(base, "Float")
        y = mem.read(base + 4, "Float")
        z = mem.read(base + 8, "Float")
        if x == 0 and y == 0 and z == 0:
            return None, char
        return (x, y, z), char








def _enum_hwnds_for_pid(pid):
    user32 = ctypes.windll.user32
    result = []
    @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    def cb(hwnd, _lp):
        p = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(p))
        if p.value == pid and user32.IsWindowVisible(hwnd):
            length = user32.GetWindowTextLengthW(hwnd)
            buf = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buf, length + 1)
            result.append((hwnd, buf.value or ""))
        return True
    user32.EnumWindows(cb, 0)
    return result


def _best_hwnd(pid):
    pairs = _enum_hwnds_for_pid(pid)
    if not pairs:
        return 0
    for hwnd, title in pairs:
        if "roblox" in title.lower():
            return hwnd
    return pairs[0][0]


def _count_roblox_pids():
    return 1 if find_pid() else 0  # find_pid returns one; recount properly below


def _all_roblox_pids():
    snap = kernel32.CreateToolhelp32Snapshot(0x02, 0)
    if snap in (0, -1):
        return []
    pe = PROCESSENTRY32W()
    pe.dwSize = ctypes.sizeof(PROCESSENTRY32W)
    out = []
    ok = kernel32.Process32FirstW(snap, ctypes.byref(pe))
    names = ("robloxplayerbeta.exe", "windows10universal.exe")
    while ok:
        if (pe.szExeFile or "").lower() in names:
            out.append(pe.th32ProcessID)
        ok = kernel32.Process32NextW(snap, ctypes.byref(pe))
    kernel32.CloseHandle(snap)
    return out


def _vk_for_mode(mode):
    m = (mode or "z").lower()
    if m in ("m1", "click", "lmb", "left"):
        return None
    if len(m) == 1 and "a" <= m <= "z":
        return ord(m.upper())
    return 0x5A


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD),
        ("wScan", wintypes.WORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
    ]


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG),
        ("dy", wintypes.LONG),
        ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
    ]


class INPUT_UNION(ctypes.Union):
    _fields_ = [("ki", KEYBDINPUT), ("mi", MOUSEINPUT)]


class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("union", INPUT_UNION)]


def _sendinput_key_sc(vk, down=True):
    """Hardware-style key via scan code (games prefer this)."""
    user32 = ctypes.windll.user32
    scan = user32.MapVirtualKeyW(vk, 0) & 0xFF
    flags = 0x0008  # KEYEVENTF_SCANCODE
    if not down:
        flags |= 0x0002  # KEYUP
    inp = INPUT()
    inp.type = 1
    inp.union.ki = KEYBDINPUT(0, scan, flags, 0, None)
    user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
    # also virtual-key path (some clients want both)
    inp2 = INPUT()
    inp2.type = 1
    inp2.union.ki = KEYBDINPUT(vk, scan, 0 if down else 0x0002, 0, None)
    user32.SendInput(1, ctypes.byref(inp2), ctypes.sizeof(INPUT))


def _sendinput_click():
    user32 = ctypes.windll.user32
    for flag in (0x0002, 0x0004):
        inp = INPUT()
        inp.type = 0
        inp.union.mi = MOUSEINPUT(0, 0, 0, flag, 0, None)
        user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))


def _post_key_to_pid(pid, mode, burst=4):
    """Send real key. No focus steal if single Roblox or already focused."""
    user32 = ctypes.windll.user32
    hwnd = _best_hwnd(pid)
    prev = user32.GetForegroundWindow()
    pids = _all_roblox_pids()
    multi = len(pids) > 1
    already = bool(hwnd and prev == hwnd)
    need_focus = multi and hwnd and not already

    tid_fg = tid_tg = 0
    try:
        if need_focus:
            fg = prev
            pid_fg = wintypes.DWORD()
            tid_fg = user32.GetWindowThreadProcessId(fg, ctypes.byref(pid_fg)) if fg else 0
            tid_tg = user32.GetWindowThreadProcessId(hwnd, None)
            if tid_fg and tid_tg and tid_fg != tid_tg:
                user32.AttachThreadInput(tid_fg, tid_tg, True)
            user32.ShowWindow(hwnd, 9)
            user32.SetForegroundWindow(hwnd)
            user32.BringWindowToTop(hwnd)
            time.sleep(0.08)

        mode = (mode or "z").lower()
        for i in range(burst):
            if mode in ("m1", "click", "lmb", "left"):
                _sendinput_click()
                time.sleep(0.03)
            else:
                vk = _vk_for_mode(mode)
                _sendinput_key_sc(vk, True)
                time.sleep(0.07)  # hold so skill registers
                _sendinput_key_sc(vk, False)
                time.sleep(0.05)
            # also keyboard module as backup (same process focus)
            try:
                import keyboard as kb
                if mode not in ("m1", "click", "lmb", "left"):
                    kb.press(mode)
                    time.sleep(0.05)
                    kb.release(mode)
            except Exception:
                pass
        return True
    finally:
        if need_focus:
            try:
                if prev:
                    user32.SetForegroundWindow(prev)
            except Exception:
                pass
            try:
                if tid_fg and tid_tg and tid_fg != tid_tg:
                    user32.AttachThreadInput(tid_fg, tid_tg, False)
            except Exception:
                pass


class AntiSoru:
    """Pure overlap fire.

    When any other player's HRP is within radius (character models overlapping),
    fire the configured key. No snap / approach / vertical logic.
    """

    def __init__(self, on_status=None):
        self.on_status = on_status or (lambda s: None)
        self.running = False
        self.enabled = False
        self.near = 5.0
        self.far = 5.0
        self.jump_min = 0.0
        self.cooldown_ms = 350
        self.mode = "z"
        self.burst = 3
        self._thread = None
        self.status = "idle"
        self.fired = 0
        self.seen_players = 0
        self.attach_pid = 0

    def configure(self, d):
        if not isinstance(d, dict):
            return
        if "enabled" in d:
            self.enabled = bool(d.get("enabled"))
        self.near = float(d.get("near", self.near))
        self.far = float(d.get("far", self.far))
        self.jump_min = float(d.get("jump_min", self.jump_min))
        self.cooldown_ms = max(40, int(d.get("cooldown_ms", self.cooldown_ms)))
        self.mode = str(d.get("mode", self.mode) or "z").lower()
        self.burst = max(1, min(12, int(d.get("burst", self.burst))))
        if not self.enabled:
            self.status = "off"

    def start(self):
        if self.running:
            return
        self.running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self.running = False
        self.enabled = False
        self.status = "off"

    def _set(self, s):
        self.status = s
        try:
            self.on_status(s)
        except Exception:
            pass

    def _children(self, mem, inst):
        out = []
        if not inst:
            return out
        try:
            ptr = mem.read(inst + OFFSETS["ChildrenStart"])
            if not ptr:
                return out
            start = mem.read(ptr)
            end = mem.read(ptr + OFFSETS["ChildrenEnd"])
            if not start or not end or end < start:
                return out
            cur = start
            for _ in range(1000):
                if cur >= end:
                    break
                child = mem.read(cur)
                if child and child != inst:
                    out.append(child)
                cur += 0x10
        except Exception:
            pass
        return out

    def _name(self, mem, inst):
        if not inst:
            return ""
        try:
            nc = mem.read(inst + OFFSETS.get("NameContainer", 104))
            if nc:
                s = mem.read_string(nc)
                if s:
                    return s
                s = mem.read_string(nc + OFFSETS.get("Name", 0))
                if s:
                    return s
            np = mem.read(inst + OFFSETS.get("Name", 0))
            if np and np > 0x10000:
                return mem.read_string(np) or ""
        except Exception:
            pass
        return ""

    def _find_child(self, mem, inst, name):
        for c in self._children(mem, inst):
            if self._name(mem, c) == name:
                return c
        return 0

    def _part_pos(self, mem, char):
        if not char:
            return None
        hrp = self._find_child(mem, char, "HumanoidRootPart")
        if not hrp:
            for nm in ("UpperTorso", "Torso", "Head"):
                hrp = self._find_child(mem, char, nm)
                if hrp:
                    break
        if not hrp:
            hum = self._find_child(mem, char, "Humanoid")
            if hum:
                hrp = mem.read(hum + OFFSETS.get("HumanoidRootPart", 1120))
        if not hrp:
            return None
        prim = mem.read(hrp + OFFSETS["Primitive"])
        if not prim:
            return None
        base = prim + OFFSETS["PrimitivePosition"]
        try:
            x = mem.read(base, "Float")
            y = mem.read(base + 4, "Float")
            z = mem.read(base + 8, "Float")
            if x != x or y != y or z != z:
                return None
            if abs(x) < 1e-6 and abs(y) < 1e-6 and abs(z) < 1e-6:
                return None
            return (x, y, z)
        except Exception:
            return None

    def _fire(self, dist):
        pid = int(getattr(self, "attach_pid", 0) or 0)
        mode = (self.mode or "z").lower()
        ok = False
        if pid:
            ok = _post_key_to_pid(pid, mode, self.burst)
        if not ok:
            try:
                import keyboard as kb
                for _ in range(self.burst):
                    if mode in ("m1", "click", "lmb", "left"):
                        kb.send("click")
                    else:
                        kb.send(mode)
                ok = True
            except Exception as e:
                self._set("anti err %s" % str(e)[:36])
                return
        self.fired += 1
        self._set("ANTI FIRE %s #%d d=%.2f" % (mode.upper(), self.fired, dist))

    def _loop(self):
        """Pure overlap: dist(local, enemy) <= radius -> fire (with cooldown)."""
        auto_update_offsets()
        mem = None
        cooldown_until = 0.0
        was_in = {}

        while self.running:
            if mem is None or not mem.alive():
                if mem:
                    try:
                        mem.close()
                    except Exception:
                        pass
                pid = find_pid()
                if not pid:
                    if self.enabled:
                        self._set("anti wait roblox")
                    time.sleep(0.5)
                    continue
                try:
                    mem = Memory(pid)
                except Exception:
                    time.sleep(0.5)
                    continue
                self.attach_pid = pid
                self._set("anti attached pid=%d" % pid)
                was_in = {}

            if not self.enabled:
                if self.status not in ("off", "idle"):
                    self._set("off")
                time.sleep(0.12)
                continue

            try:
                fake = mem.read(mem.base + OFFSETS["FakeDataModelPtr"])
                dm = mem.read(fake + OFFSETS["RealDataModel"]) if fake else 0
                players = self._find_child(mem, dm, "Players") if dm else 0
                if not players:
                    self._set("no Players")
                    time.sleep(0.1)
                    continue
                lp = mem.read(players + OFFSETS["LocalPlayer"])
                local_char = mem.read(lp + OFFSETS["ModelInstance"]) if lp else 0
                local_pos = self._part_pos(mem, local_char)
                if not local_pos:
                    self._set("no local HRP")
                    time.sleep(0.04)
                    continue

                now = time.time() * 1000.0
                radius = max(1.5, min(20.0, float(self.near)))

                triggered = False
                trig_d = 0.0
                n_others = 0
                closest = 1e9
                seen = set()

                for pl in self._children(mem, players):
                    if not pl or pl == lp:
                        continue
                    char = mem.read(pl + OFFSETS["ModelInstance"])
                    if not char or char < 0x10000:
                        continue
                    pos = self._part_pos(mem, char)
                    if not pos:
                        continue
                    n_others += 1
                    seen.add(pl)
                    dist = math.sqrt(
                        (pos[0] - local_pos[0]) ** 2
                        + (pos[1] - local_pos[1]) ** 2
                        + (pos[2] - local_pos[2]) ** 2
                    )
                    if dist < closest:
                        closest = dist

                    inside = dist <= radius
                    prev = was_in.get(pl, False)
                    if inside and not prev and now >= cooldown_until:
                        triggered = True
                        trig_d = dist
                        was_in[pl] = True
                        break
                    was_in[pl] = inside

                self.seen_players = n_others
                for k in list(was_in.keys()):
                    if k not in seen:
                        was_in.pop(k, None)

                if triggered:
                    cooldown_until = now + max(60, int(self.cooldown_ms))
                    self._fire(trig_d)
                    self._fire_until = now + 700.0
                elif now > float(getattr(self, "_fire_until", 0) or 0):
                    if n_others == 0:
                        self._set("watch n=0")
                    else:
                        dshow = closest if closest < 1e8 else -1
                        self._set("n=%d d=%.2f r=%.1f" % (n_others, dshow, radius))

                time.sleep(0.004)
            except Exception as e:
                self._set("anti loop %s" % str(e)[:40])
                try:
                    mem.close()
                except Exception:
                    pass
                mem = None
                time.sleep(0.3)
